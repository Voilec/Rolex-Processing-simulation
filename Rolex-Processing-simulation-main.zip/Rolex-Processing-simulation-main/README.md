# Rolex-Processing-simulation
Drawing beautiful Rolex clock very simply with Processing
