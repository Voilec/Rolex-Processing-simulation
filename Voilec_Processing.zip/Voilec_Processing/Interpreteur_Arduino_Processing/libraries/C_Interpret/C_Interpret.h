//***********************************//
//            Interpteter            //
//      Arduino <-> Processing       //
//  Draw on PC screen from Arduino   //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
//   220108

#ifndef _CINTP 
#define _CINTP

#include <Arduino.h> // for Serial

//*************************************

class C_Interpret 
{
private:

void sendCommand(const int command);  // int +0

template <typename T> //  +1 
void sendCommand(const int command, const T& data1)
{
Serial.print(command);
Serial.print(",");
Serial.print(data1) ; // T String or int
Serial.println(","); 
}

template <typename T1, typename T> //  +2 
void sendCommand(const int command, const T1& data1, const T& data2)  
{
Serial.print(command);  // int
Serial.print(",");
Serial.print(data1) ; // T1 String or int
Serial.print(",");
Serial.print(data2) ; // int
Serial.println(","); 
}

template <typename T1, typename T> //  +3 
void sendCommand(const int command, const T1& data1, const T& data2, const T& data3)  
{
Serial.print(command);  // int
Serial.print(",");
Serial.print(data1) ; // T1 String or int
Serial.print(",");
Serial.print(data2) ;  // int
Serial.print(",");
Serial.print(data3) ;  // int
Serial.println(","); 
}

template <typename T1, typename T> //  +4 
void sendCommand(const int command, const T1& data1, const T& data2, const T& data3, const T& data4)  
{
Serial.print(command); // int
Serial.print(",");
Serial.print(data1) ; // T1 String or int
Serial.print(",");
Serial.print(data2) ; // int
Serial.print(",");
Serial.print(data3) ; // int
Serial.print(",");
Serial.print(data4) ; // int
Serial.println(","); 
}

template <typename T1, typename T> //  +5 
void sendCommand(const int command, const T1& data1, const T& data2, const T& data3, const T& data4, const T& data5)  
{
Serial.print(command); // int
Serial.print(",");
Serial.print(data1) ; // T1 String or int
Serial.print(",");
Serial.print(data2) ; // int
Serial.print(",");
Serial.print(data3) ; // int
Serial.print(",");
Serial.print(data4) ; // int
Serial.print(",");
Serial.print(data5) ; // int
Serial.println(","); 
}

template <typename T1, typename T> //  +6 
void sendCommand(const int command, const T1& data1, const T& data2, const T& data3, const T& data4, const T& data5, const T& data6)  
{
Serial.print(command);
Serial.print(",");
Serial.print(data1) ; // T1 String or int
Serial.print(",");
Serial.print(data2) ; // int
Serial.print(",");
Serial.print(data3) ; // int
Serial.print(",");
Serial.print(data4) ; // int
Serial.print(",");
Serial.print(data5) ; // int
Serial.print(",");
Serial.print(data6) ; // int
Serial.println(","); 
}

//************************************* 

public:
void background (int red, int green, int blue) ;
void textSize (int fontH) ;
// loadFont
void labelNum (int label, int posX0, int posY0) ;
void labelText (String label, int posX0, int posY0) ;
void placeImage (String label, int posX0, int posY0, int xSize, int ySize) ;
void strokeWeight(int thick) ;
void noStroke () ;// Disable stroke (outline) 
void noFill () ; // Empty form 
void fillForm (int red, int green, int blue) ; // Fill form 
void point (int posX0, int posY0) ;
void segment (int posX0, int posY0, int posX1, int posY1) ;
void rectangleCorners (int posX0, int posY0, int posX1, int posY1) ; // No need for floating
void rectangleDelta (int posX0, int posY0, int widthRec , int heightRec) ; // Origin corner NW
void rectangleCenter (int posX0, int posY0, int widthRec , int heightRec) ; // Origin center
// rect radius
void circle (int posX0, int posY0, int ray) ; // Default is diameter
void ellipseCenter () ; // default:  x0, y0 = center point // width, height
void ellipseCorner () ; // x0, y0 = corner NW // width, height
void ellipseCorners () ; // x0, y0 = corner NW // x1, y1 = corner SE 
void ellipse (int posX0, int posY0, int x1 , int y1) ; // No need for floating
// arc, curve, scale
// quad
// bezier
// shape , random
void triangle (int posX0, int posY0, int posX1, int posY1, int posX2, int posY2) ;
void translate (int posX0, int posY0);
void rotateDeg(float degres) ;
void rotateRad(float rad) ;
void colorTextFrames (int red, int green, int blue) ; // color to fill frames and text
void colorLines (int red, int green, int blue); // color to draw lines & borders

// ***********************************************

C_Interpret ();
~C_Interpret();	
};

// ***********************************************
#endif
// ***********************************************
