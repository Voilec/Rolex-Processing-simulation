//***********************************//
//            Interpteter            //
//      Arduino <-> Processing       //
//  Draw on PC screen from Arduino   //
//***********************************//
//        Christian Couderc          //
//         www.voilec.com            //
//***********************************//
//   220108

#include "C_Interpret.h"

//*************************************

void C_Interpret::background (int red, int green, int blue)
{ delay (11); sendCommand (10, red, green, blue) ; delay (100); }

void C_Interpret::textSize (int fontH)
{ sendCommand (20, fontH); }

void C_Interpret::labelNum (int label, int posX0, int posY0)
{ sendCommand (22, label, posX0, posY0); }

void C_Interpret::labelText (String label, int posX0, int posY0) // one  string, two int
{ sendCommand (23, label, posX0, posY0); }

void C_Interpret::placeImage (String label, int posX0, int posY0, int xSize, int ySize) // one  string, four int
{ sendCommand (24, label, posX0, posY0, xSize, ySize); }

void C_Interpret::strokeWeight(int thick)  // Width of lines Thicker = 16
{ sendCommand (31, thick); }

void C_Interpret::noStroke () // Disable stroke (outline) 
{ sendCommand (32) ; }  

void C_Interpret::noFill () // Empty form 
{ sendCommand (33) ; }  

void C_Interpret::fillForm (int red, int green, int blue) // Fill form 
{ sendCommand (34, red, green, blue) ; } 

void C_Interpret::point (int posX0, int posY0)
{ sendCommand (40, posX0, posY0) ;}

void C_Interpret::segment (int posX0, int posY0, int posX1, int posY1)
{ sendCommand (41, posX0, posY0, posX1, posY1) ;}

void C_Interpret::rectangleCorners (int posX0, int posY0, int posX1, int posY1)
{ sendCommand (42, posX0, posY0, posX1-posX0 , posY1-posY0) ;}

void C_Interpret::rectangleDelta (int posX0, int posY0, int widthRec , int heightRec)
{ sendCommand (42, posX0, posY0, widthRec , heightRec) ;}

void C_Interpret::rectangleCenter (int posX0, int posY0, int widthRec , int heightRec)
{ sendCommand (42, posX0-widthRec, posY0-heightRec, posX0+widthRec , posY0+heightRec) ;}

void C_Interpret::circle (int posX0, int posY0, int ray) // Delault is diameter
{ sendCommand (50, posX0, posY0, 2*ray) ;}

void C_Interpret::ellipseCenter ()  // default:  x0, y0 = center point // width, height
{ sendCommand (70) ; }  

void C_Interpret::ellipseCorner ()  // x0, y0 = corner NW // width, height
{ sendCommand (71) ; }
  
void C_Interpret::ellipseCorners ()  // x0, y0 = corner NW // x1, y1 = corner SE 
{ sendCommand (72) ; } 
 
void C_Interpret::ellipse (int posX0, int posY0, int x1 , int y1) 
{ sendCommand (73, posX0, posY0, x1, y1) ;}

void C_Interpret::triangle (int posX0, int posY0, int posX1, int posY1, int posX2, int posY2)
{ sendCommand (51, posX0, posY0, posX1, posY1, posX2, posY2 ) ;}

void C_Interpret::translate (int posX0, int posY0)
{ sendCommand (54, posX0, posY0) ;}

void C_Interpret::rotateDeg(float degres)
{ sendCommand (55, degres) ;}

void C_Interpret::rotateRad(float radians)
{ sendCommand (56, radians) ;}

void C_Interpret::colorTextFrames (int red, int green, int blue) // color to fill frames and text
{ sendCommand (60, red, green, blue); }

void C_Interpret::colorLines (int red, int green, int blue) // color to draw lines & borders
{ sendCommand (61, red, green, blue); }

//************************************* 

void C_Interpret::sendCommand (int command)  // bare command : +0 int
{  
Serial.print (command) ; 
Serial.println(","); 
}   

// ****************************************************

C_Interpret::C_Interpret()
{}
C_Interpret::~C_Interpret()
{}

// ****************************************************
// ****************************************************
